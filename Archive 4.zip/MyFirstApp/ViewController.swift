//
//  ViewController.swift
//  MyFirstApp
//
//  Created by user162559 on 3/17/20.
//  Copyright © 2020 Mike Mendizabal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // MARK: Properties
    @IBOutlet var labelResult: UILabel!
    @IBOutlet var textMessage: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: Methods
    @IBAction func changeButton(_ sender: UIButton) {
        labelResult.text = textMessage.text?.uppercased()
        print (labelResult.text!)
    }
}

